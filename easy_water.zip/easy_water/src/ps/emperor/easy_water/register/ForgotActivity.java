package ps.emperor.easy_water.register;

import ps.emperor.easy_water.BaseActivity;
import ps.emperor.easy_water.R;
import android.os.Bundle;

public class ForgotActivity extends BaseActivity {
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_forgot);
	}

}
