package ps.emperor.easy_water.view;

public class Snippet {
	public static void main(String[] args) {
	}
}

