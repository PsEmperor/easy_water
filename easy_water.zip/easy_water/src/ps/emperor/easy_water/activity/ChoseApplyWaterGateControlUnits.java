package ps.emperor.easy_water.activity;

import android.os.Bundle;
import ps.emperor.easy_water.BaseActivity;
import ps.emperor.easy_water.R;

public class ChoseApplyWaterGateControlUnits extends BaseActivity{
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_irrigate_or_water);


//		index = 1;
//		clearStatus();
	}
	
}
