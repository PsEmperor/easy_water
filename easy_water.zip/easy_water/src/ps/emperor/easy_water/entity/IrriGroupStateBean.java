package ps.emperor.easy_water.entity;


public class IrriGroupStateBean {

	/**
	 * 灌溉组控制返回状态码
	 * @author 毛国江
	 * @version 2017-2-15
	 */


	public String code;

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}
	
}
