package ps.emperor.easy_water.entity;

public class ApplyIrrigationProject {
	/**
	 * 灌溉单元控制（应用）
	 */

	public String name; // 种植户

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	
}
