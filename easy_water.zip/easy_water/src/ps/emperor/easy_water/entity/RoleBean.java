package ps.emperor.easy_water.entity;

/**
 * 角色申请
 * @author 毛国江
 * @version 2017-1-3 16:11
 */
public class RoleBean {

	public String role; //角色
	public String msg; //信息描述

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

}
 